<?php

  namespace Drupal\hello\Controller;

  use Drupal\Core\Controller\ControllerBase;

  class HelloController extends ControllerBase { 

     public function sayhello() { 
      
        return array(

           '#markup' => hello_hello_world(),

        );

     }

     public function welcome() { 
      
        return array(

           '#markup' => hello_welcome(),

        );

     }


     public function create_node() { 
      
        return array(

           '#markup' => hello_create_node(),

        );

     }


 
  }
