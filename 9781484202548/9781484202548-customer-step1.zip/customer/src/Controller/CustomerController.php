<?php

namespace Drupal\customer\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * Controller routines for node_type_example.
 *
 * @ingroup node_type_example
 */
class CustomerController extends ControllerBase {

  /**
   * A simple controller method to explain what this module is about.
   */
  public function description() {
    // Construct our links.
    $content_admin_link = Link::createFromRoute($this->t('the content type admin page'), 'entity.node_type.collection')->toString();

    // We can generate a URL fragment for an admin route. If the path is changed
    // for this route, this code will change it in the content displayed to the
    // user.
    $add_types = Url::fromRoute('node.type_add');
    $add_types_url = $add_types->toString();

    $build = array(
      '#markup' => t(
          'This is a very basic customer content type',
        array(
          '@content_type_admin' => $content_admin_link,
          '@add_types_url' => $add_types_url,
        )
      ),
    );
    return $build;
  }

}
